# A Simple Personal Brand Website
## [ShaneKunz.com](https://shanekunz.com)

This project uses a node express server, a bootstrap template I copied. It is deployed on AWS elastic beanstalk.

One day I'll put together a more proper site with a blog.
